using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Card : MonoBehaviour
{
    public string suit;
    public int value;
    public Sprite frontSprite;
    public Sprite backSprite; // assign this during setup

    private SpriteRenderer sr;

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
    }

    public void Setup(string suit, int value, Sprite front, Sprite back)
    {
        this.suit = suit;
        this.value = value;
        frontSprite = front;
        backSprite = back;
        GetComponent<SpriteRenderer>().sprite = backSprite;
    }

    private IEnumerator FlipAnimation()
    {
        // Scale X to 0 (side view)
        float duration = 0.2f;
        float time = 0f;
        while (time < duration)
        {
            float scale = Mathf.Lerp(1f, 0f, time / duration);
            transform.localScale = new Vector3(scale, 1, 1);
            time += Time.deltaTime;
            yield return null;
        }

        // Swap sprite to front
        sr.sprite = frontSprite;

        // Scale X back to 1
        time = 0f;
        while (time < duration)
        {
            float scale = Mathf.Lerp(0f, 1f, time / duration);
            transform.localScale = new Vector3(scale, 1, 1);
            time += Time.deltaTime;
            yield return null;
        }

        transform.localScale = Vector3.one;
    }
    public int GetCardValue()
    {
        // Treat Ace (1) as highest
        return value == 1 ? 14 : value;
    }
}
