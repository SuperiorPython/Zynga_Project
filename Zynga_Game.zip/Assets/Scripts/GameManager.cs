﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameManager : MonoBehaviour
{
    public DeckManager deckManager;
    public Transform[] playPositions; // 0: player, 1-3: CPUs
    public Button playRoundButton;
    public TextMeshProUGUI[] cardCounters = new TextMeshProUGUI[4];
    public Transform centerPosition;
    public Vector3 cardScale = new Vector3(3f, 3f, 1f);

    private GameObject[] playedCards = new GameObject[4];
    private bool isPlayingRound = false;

    void Start()
    {
        playRoundButton.onClick.AddListener(() => StartCoroutine(PlayRoundRoutine()));
    }

    void UpdateCardCounters()
    {
        for (int i = 0; i < 4; i++)
        {
            int count = deckManager.playerHands[i].Count;
            cardCounters[i].text = $"Cards: {count}";
        }
    }
    IEnumerator PlayRoundRoutine()
    {
        isPlayingRound = true;
        playRoundButton.interactable = false;

        ClearOldCards();

        for (int i = 0; i < 4; i++)
        {
            if (deckManager.playerHands[i].Count > 0)
            {
                GameObject card = deckManager.playerHands[i][0];
                deckManager.playerHands[i].RemoveAt(0);
                playedCards[i] = card;

                card.transform.position = playPositions[i].position;
                card.SetActive(true);
                card.transform.localScale = cardScale;
            }
        }

        yield return StartCoroutine(PlayAnimation());

        isPlayingRound = false;
        playRoundButton.interactable = true;
    }
    public void PlayRound()
    {
        if (!isPlayingRound)
        {
            StartCoroutine(PlayRoundRoutine());
        }
    }
    void ShowNextTopCards()
    {
        for (int i = 0; i < 4; i++)
        {
            List<GameObject> hand = deckManager.playerHands[i];
            if (hand.Count > 0)
            {
                GameObject nextCard = hand[0];
                nextCard.transform.position = playPositions[i].position;

                SpriteRenderer sr = nextCard.GetComponent<SpriteRenderer>();
                sr.sprite = nextCard.GetComponent<Card>().backSprite;
                sr.color = GetPlayerColor(i);
                nextCard.SetActive(true);
                nextCard.transform.localScale = cardScale;
            }
        }
    }

    Color GetPlayerColor(int i)
    {
        return i switch
        {
            0 => Color.green,
            1 => Color.red,
            2 => Color.blue,
            3 => Color.yellow,
            _ => Color.white
        };
    }

    private IEnumerator FlipAndMoveToCenter(GameObject card)
    {
        yield return StartCoroutine(FlipCard(card));
        yield return StartCoroutine(MoveCardToPosition(card, centerPosition.position));
    }
    private IEnumerator PlayAnimation()
    {
        // Move cards toward the center from 4 directions
        yield return StartCoroutine(MoveCardToPosition(playedCards[0], centerPosition.position + Vector3.down * 2f));  // player
        yield return StartCoroutine(MoveCardToPosition(playedCards[1], centerPosition.position + Vector3.up * 2f));    // cpu1
        yield return StartCoroutine(MoveCardToPosition(playedCards[2], centerPosition.position + Vector3.left * 2f));  // cpu2
        yield return StartCoroutine(MoveCardToPosition(playedCards[3], centerPosition.position + Vector3.right * 2f)); // cpu3

        yield return new WaitForSeconds(0.3f);

        // Flip each card
        for (int i = 0; i < 4; i++)
        {
            if (playedCards[i] != null)
                yield return StartCoroutine(FlipCard(playedCards[i]));
        }

        // Determine winner
        int highestValue = -1;
        List<int> tiedPlayers = new List<int>();
        int winnerIndex = -1;

        for (int i = 0; i < 4; i++)
        {
            if (playedCards[i] == null) continue;

            int val = playedCards[i].GetComponent<Card>().GetCardValue();

            if (val > highestValue)
            {
                highestValue = val;
                tiedPlayers.Clear();
                tiedPlayers.Add(i);
                winnerIndex = i;
            }
            else if (val == highestValue)
            {
                tiedPlayers.Add(i);
            }
        }

        yield return new WaitForSeconds(0.5f);

        if (tiedPlayers.Count > 1)
        {
            Debug.Log("Initial tie detected! Starting war...");
            yield return StartCoroutine(ResolveWar(tiedPlayers, new List<GameObject>(playedCards)));
            yield break; // Stop further execution of this coroutine
        }

        // If no tie, distribute cards to winner
        Vector3 winnerTarget = playPositions[winnerIndex].position;

        foreach (GameObject card in playedCards)
        {
            if (card != null)
            {
                yield return StartCoroutine(MoveCardToPosition(card, winnerTarget));
                card.SetActive(false);
                deckManager.playerHands[winnerIndex].Add(card);
            }
        }

        UpdateCardCounters();
        ShowNextTopCards();
    }

    private IEnumerator FlipCard(GameObject card)
    {
        float duration = 0.2f;
        float time = 0f;
        Vector3 originalScale = card.transform.localScale;

        // Shrink X to 0
        while (time < duration)
        {
            float scale = Mathf.Lerp(1f, 0f, time / duration);
            card.transform.localScale = new Vector3(scale, 1f, 1f);
            time += Time.deltaTime;
            yield return null;
        }

        // Swap sprite to front face
        SpriteRenderer sr = card.GetComponent<SpriteRenderer>();
        sr.sprite = card.GetComponent<Card>().frontSprite;

        // Expand X back to 1
        time = 0f;
        while (time < duration)
        {
            float scale = Mathf.Lerp(0f, 1f, time / duration);
            card.transform.localScale = new Vector3(scale, 1f, 1f);
            time += Time.deltaTime;
            yield return null;
        }

        card.transform.localScale = originalScale;
    }

    private IEnumerator ResolveWar(List<int> tiedPlayers, List<GameObject> accumulatedPile)
    {
        yield return new WaitForSeconds(0.5f);

        List<GameObject> newWarCards = new List<GameObject>();
        List<int> finalTiedPlayers = new List<int>();
        int highest = -1;

        foreach (int i in tiedPlayers)
        {
            var hand = deckManager.playerHands[i];
            int available = hand.Count;

            if (available == 0)
            {
                Debug.Log($"Player {i + 1} has no cards left for war!");
                continue;
            }

            int revealCount = Mathf.Min(3, Mathf.Max(0, available - 1));
            for (int j = 0; j < revealCount; j++)
            {
                GameObject revealCard = hand[0];
                hand.RemoveAt(0);
                newWarCards.Add(revealCard);

                revealCard.transform.position = playPositions[i].position + new Vector3(0.3f * (j - 1), 0.2f * (j - 1), 0);
                revealCard.SetActive(true);
                yield return StartCoroutine(FlipCard(revealCard));
            }

            GameObject warCard = hand[0];
            hand.RemoveAt(0);
            newWarCards.Add(warCard);

            warCard.transform.position = playPositions[i].position;
            warCard.SetActive(true);
            yield return StartCoroutine(FlipAndMoveToCenter(warCard));

            int value = warCard.GetComponent<Card>().GetCardValue();
            Debug.Log($"Player {i + 1} war card: {value}");

            if (value > highest)
            {
                highest = value;
                finalTiedPlayers.Clear();
                finalTiedPlayers.Add(i);
            }
            else if (value == highest)
            {
                finalTiedPlayers.Add(i);
            }
        }

        // Merge all new war cards into the running pile
        accumulatedPile.AddRange(newWarCards);

        if (finalTiedPlayers.Count == 1)
        {
            int winner = finalTiedPlayers[0];
            Debug.Log($"Player {winner + 1} wins the war and takes all {accumulatedPile.Count} cards!");

            Vector3 winnerTarget = playPositions[winner].position;

            foreach (var card in accumulatedPile)
            {
                if (card != null)
                {
                    yield return StartCoroutine(MoveCardToPosition(card, winnerTarget));
                    card.SetActive(false);
                    deckManager.playerHands[winner].Add(card);
                }
            }

            for (int i = 0; i < playedCards.Length; i++)
                playedCards[i] = null;

            UpdateCardCounters();
            ShowNextTopCards();
        }
        else
        {
            Debug.Log("War tied again! Going deeper...");
            yield return StartCoroutine(ResolveWar(finalTiedPlayers, accumulatedPile));
        }
    }



    IEnumerator HandleWinnerAfterDelay(GameObject[] cards, List<int> tiedPlayers, int[] values)
    {
        yield return new WaitForSeconds(0.5f);

        int winner = -1;
        int highest = -1;

        foreach (int i in tiedPlayers)
        {
            if (values[i] > highest)
            {
                highest = values[i];
                winner = i;
            }
        }

        // Move all cards to the winner
        Vector3 winnerPos = playPositions[winner].position;

        foreach (GameObject card in cards)
        {
            if (card != null)
            {
                yield return StartCoroutine(MoveCard(card, winnerPos));
                card.SetActive(false);
                deckManager.playerHands[winner].Add(card);
            }
        }

        UpdateCardCounters();
    }

    private IEnumerator MoveCardsToWinner(int winnerIndex)
    {
        Vector3 target = playPositions[winnerIndex].position;

        Debug.Log($"[FIXED] Player {winnerIndex + 1} wins. Moving all cards to their stack.");

        for (int i = 0; i < playedCards.Length; i++)
        {
            GameObject card = playedCards[i];
            if (card != null)
            {
                yield return StartCoroutine(MoveCard(card, target));
                card.SetActive(false);
                deckManager.playerHands[winnerIndex].Add(card);
                playedCards[i] = null;
            }
        }

        UpdateCardCounters();
        ShowNextTopCards();
    }


    void ClearOldCards()
    {
        for (int i = 0; i < playedCards.Length; i++)
        {
            if (playedCards[i] != null)
            {
                playedCards[i].SetActive(false);
                playedCards[i].transform.localScale = Vector3.one;
                playedCards[i] = null;
            }
        }
    }

    void CheckGameOver()
    {
        int alive = 0;
        int last = -1;
        for (int i = 0; i < 4; i++)
        {
            if (deckManager.playerHands[i].Count > 0)
            {
                alive++;
                last = i;
            }
        }

        if (alive == 1)
        {
            Debug.Log($"Game Over! Player {last + 1} wins!");
            playRoundButton.interactable = false;
        }
    }

    IEnumerator MoveCard(GameObject card, Vector3 targetPos, float speed = 5f)
    {
        while (Vector3.Distance(card.transform.position, targetPos) > 0.01f)
        {
            card.transform.position = Vector3.MoveTowards(card.transform.position, targetPos, speed * Time.deltaTime);
            yield return null;
        }
        card.transform.position = targetPos;
    }
    IEnumerator MoveCardToPosition(GameObject card, Vector3 targetPos, float duration = 0.5f)
    {
        Vector3 startPos = card.transform.position;
        float elapsed = 0f;

        while (elapsed < duration)
        {
            card.transform.position = Vector3.Lerp(startPos, targetPos, elapsed / duration);
            elapsed += Time.deltaTime;
            yield return null;
        }

        card.transform.position = targetPos;
    }
}
