using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeckManager : MonoBehaviour
{
    public GameObject cardPrefab;
    public Sprite[] cardSprites;        // 52 face sprites
    public Sprite cardBackSprite;       // Back of the card
    public Transform[] playPositions;   // 4 play positions (assign in Inspector)
    public Vector3 cardScale = new Vector3(3f, 3f, 1f);

    public List<GameObject>[] playerHands = new List<GameObject>[4];

    private string[] suits = { "Clubs", "Diamonds", "Hearts", "Spades" };

    void Start()
    {
        // Auto-fill playPositions if not assigned
        if (playPositions == null || playPositions.Length < 4)
        {
            Debug.LogWarning("playPositions not assigned � attempting auto-assign.");
            playPositions = new Transform[4];
            for (int i = 0; i < 4; i++)
            {
                var obj = GameObject.Find($"PlayPosition{i}");
                if (obj != null)
                    playPositions[i] = obj.transform;
                else
                    Debug.LogError($"Missing GameObject named PlayPosition{i}");
            }
        }

        CreateAndDealDeck();
    }

    void CreateAndDealDeck()
    {
        if (playPositions == null || playPositions.Length < 4)
        {
            Debug.LogError("playPositions must be assigned and contain exactly 4 elements in the Inspector!");
            return;
        }

        List<GameObject> deck = new List<GameObject>();
        int spriteIndex = 0;

        // Create 52 cards
        foreach (string suit in suits)
        {
            for (int value = 1; value <= 13; value++) // Ace to King
            {
                GameObject card = Instantiate(cardPrefab, transform);
                Card cardScript = card.GetComponent<Card>();
                cardScript.Setup(suit, value, cardSprites[spriteIndex], cardBackSprite);
                card.SetActive(false); // Hide for now
                deck.Add(card);
                spriteIndex++;
            }
        }

        Shuffle(deck);

        // Initialize hands
        for (int i = 0; i < 4; i++)
            playerHands[i] = new List<GameObject>();

        // Deal evenly to 4 players
        for (int i = 0; i < deck.Count; i++)
        {
            int playerIndex = i % 4;
            GameObject card = deck[i];
            playerHands[playerIndex].Add(card);

            // Assign player color
            Color color = Color.white;
            switch (playerIndex)
            {
                case 0: color = Color.green; break;
                case 1: color = Color.red; break;
                case 2: color = Color.blue; break;
                case 3: color = Color.yellow; break;
            }

            card.GetComponent<SpriteRenderer>().color = color;
            card.transform.localScale = cardScale; // apply card scale here
        }


        // Display the top card (face-down) for each player
        for (int i = 0; i < 4; i++)
        {
            if (playerHands[i].Count > 0)
            {
                GameObject topCard = playerHands[i][0];
                topCard.transform.position = playPositions[i].position;
                topCard.GetComponent<SpriteRenderer>().sprite = cardBackSprite;
                topCard.SetActive(true);
            }
        }

        Debug.Log("Deck created and dealt. Top cards placed.");
    }

    void Shuffle(List<GameObject> list)
    {
        for (int i = 0; i < list.Count; i++)
        {
            int rnd = Random.Range(i, list.Count);
            GameObject temp = list[rnd];
            list[rnd] = list[i];
            list[i] = temp;
        }
    }
}
